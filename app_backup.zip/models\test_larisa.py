import asyncio
from app.database.connection import get_db, init_db
from app.services.auth_service import AuthService

async def test():
    await init_db()
    async for session in get_db():
        svc = AuthService(session)
        # Try login first
        try:
            user, access, refresh = await svc.login(
                email="kozuballarisa@gmail.com",
                password="Larisa2026!",
            )
            print(f"LOGIN OK! user_id={user.id}")
            print(f"TOKEN: {access}")
            return
        except Exception:
            pass

        # Register if login failed
        try:
            user, access, refresh = await svc.register(
                email="kozuballarisa@gmail.com",
                password="Larisa2026!",
                name="Larisa Kozubal",
                role="practitioner",
            )
            print(f"REGISTER OK! user_id={user.id}")
            print(f"TOKEN: {access}")
        except Exception as e:
            print(f"ERROR: {e}")

asyncio.run(test())